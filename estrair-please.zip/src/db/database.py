import sqlite3
import os
from datetime import datetime
from typing import Optional


DB_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "modpack_analyzer.db")


class Database:
    _instance: Optional["Database"] = None

    def __init__(self, db_path: str = DB_PATH):
        self.db_path = os.path.abspath(db_path)
        self.conn: Optional[sqlite3.Connection] = None

    @classmethod
    def get(cls, db_path: str = DB_PATH) -> "Database":
        if cls._instance is None:
            cls._instance = cls(db_path)
        return cls._instance

    def connect(self) -> sqlite3.Connection:
        if self.conn is None:
            self.conn = sqlite3.connect(self.db_path)
            self.conn.row_factory = sqlite3.Row
            self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.execute("PRAGMA foreign_keys=ON")
        return self.conn

    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    def init_db(self):
        conn = self.connect()
        current_version = conn.execute("PRAGMA user_version").fetchone()[0]
        if current_version == 0:
            self._migrate_v1(conn)
            current_version = 1
        if current_version == 1:
            self._migrate_v1_to_v2(conn)

    def _migrate_v1_to_v2(self, conn: sqlite3.Connection):
        cursor = conn.execute("PRAGMA table_info(mods)")
        cols = [row[1] for row in cursor.fetchall()]
        if "version" not in cols:
            conn.execute("ALTER TABLE mods ADD COLUMN version TEXT NOT NULL DEFAULT ''")
        conn.execute("PRAGMA user_version = 2")
        conn.commit()

    def _migrate_v1(self, conn: sqlite3.Connection):
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS modpacks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL DEFAULT '',
                game_version TEXT NOT NULL DEFAULT '',
                modloader TEXT NOT NULL DEFAULT '',
                source_file TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                updated_at TEXT NOT NULL DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS mods (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                slug TEXT NOT NULL DEFAULT '',
                name TEXT NOT NULL DEFAULT '',
                source TEXT NOT NULL DEFAULT '',
                source_id TEXT NOT NULL DEFAULT '',
                description TEXT NOT NULL DEFAULT '',
                game_versions TEXT NOT NULL DEFAULT '',
                modloader TEXT NOT NULL DEFAULT '',
                version TEXT NOT NULL DEFAULT '',
                download_url TEXT NOT NULL DEFAULT '',
                cached_at TEXT
            );

            CREATE TABLE IF NOT EXISTS modpack_mods (
                modpack_id INTEGER NOT NULL,
                mod_id INTEGER NOT NULL,
                is_optional INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (modpack_id, mod_id),
                FOREIGN KEY (modpack_id) REFERENCES modpacks(id) ON DELETE CASCADE,
                FOREIGN KEY (mod_id) REFERENCES mods(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS dependencies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                mod_id INTEGER NOT NULL,
                depends_on_mod_id INTEGER NOT NULL DEFAULT 0,
                depends_on_slug TEXT NOT NULL DEFAULT '',
                type TEXT NOT NULL DEFAULT 'required',
                source TEXT NOT NULL DEFAULT '',
                FOREIGN KEY (mod_id) REFERENCES mods(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS incompatibilities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                mod_a_id INTEGER NOT NULL,
                mod_b_id INTEGER NOT NULL DEFAULT 0,
                mod_b_slug TEXT NOT NULL DEFAULT '',
                description TEXT NOT NULL DEFAULT '',
                severity TEXT NOT NULL DEFAULT 'critical',
                source TEXT NOT NULL DEFAULT '',
                FOREIGN KEY (mod_a_id) REFERENCES mods(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS analysis_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                modpack_id INTEGER NOT NULL,
                score INTEGER NOT NULL DEFAULT 0,
                total_mods INTEGER NOT NULL DEFAULT 0,
                missing_deps INTEGER NOT NULL DEFAULT 0,
                conflicts INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                FOREIGN KEY (modpack_id) REFERENCES modpacks(id) ON DELETE CASCADE
            );

            CREATE TABLE IF NOT EXISTS analysis_details (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                analysis_id INTEGER NOT NULL,
                mod_id INTEGER NOT NULL DEFAULT 0,
                mod_name TEXT NOT NULL DEFAULT '',
                issue_type TEXT NOT NULL DEFAULT '',
                description TEXT NOT NULL DEFAULT '',
                suggested_action TEXT NOT NULL DEFAULT '',
                FOREIGN KEY (analysis_id) REFERENCES analysis_history(id) ON DELETE CASCADE
            );

            CREATE INDEX IF NOT EXISTS idx_deps_mod ON dependencies(mod_id);
            CREATE INDEX IF NOT EXISTS idx_incompat_mod ON incompatibilities(mod_a_id);
            CREATE INDEX IF NOT EXISTS idx_analysis_modpack ON analysis_history(modpack_id);
            PRAGMA user_version = 1;
        """)
        conn.commit()

    # --- CRUD helpers ---

    def insert(self, table: str, **kwargs) -> int:
        cols = ", ".join(kwargs.keys())
        placeholders = ", ".join("?" for _ in kwargs)
        values = list(kwargs.values())
        cur = self.connect().execute(
            f"INSERT INTO {table} ({cols}) VALUES ({placeholders})", values
        )
        self.conn.commit()
        return cur.lastrowid

    def update(self, table: str, row_id: int, **kwargs):
        sets = ", ".join(f"{k}=?" for k in kwargs)
        values = list(kwargs.values()) + [row_id]
        self.connect().execute(f"UPDATE {table} SET {sets} WHERE id=?", values)
        self.conn.commit()

    def delete(self, table: str, row_id: int):
        self.connect().execute(f"DELETE FROM {table} WHERE id=?", (row_id,))
        self.conn.commit()

    def fetch_all(self, table: str, where: str = "", params: tuple = ()) -> list[sqlite3.Row]:
        q = f"SELECT * FROM {table}"
        if where:
            q += f" WHERE {where}"
        return self.connect().execute(q, params).fetchall()

    def fetch_one(self, table: str, where: str = "", params: tuple = ()) -> Optional[sqlite3.Row]:
        rows = self.fetch_all(table, where, params)
        return rows[0] if rows else None

    def fetch_mods_for_modpack(self, modpack_id: int) -> list[sqlite3.Row]:
        return self.fetch_all(
            "mods",
            "id IN (SELECT mod_id FROM modpack_mods WHERE modpack_id=?)",
            (modpack_id,),
        )

    def fetch_analysis_history(self, modpack_id: int) -> list[sqlite3.Row]:
        return self.fetch_all(
            "analysis_history",
            "modpack_id=? ORDER BY created_at DESC",
            (modpack_id,),
        )
