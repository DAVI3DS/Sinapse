import sys
import logging
from PySide6.QtWidgets import QApplication

from src.db.database import Database
from src.ui.main_window import MainWindow

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)


class ModpackAnalyzerApp(QApplication):
    def __init__(self, argv: list[str]):
        super().__init__(argv)
        self.setApplicationName("Modpack Analyzer")
        self.setOrganizationName("ModpackAnalyzer")

        db = Database.get()
        db.init_db()

        self.main_window = MainWindow()
        self.main_window.show()
