from pathlib import Path

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
    QLabel, QFileDialog, QComboBox, QFrame,
)
from PySide6.QtCore import Signal, Qt
from PySide6.QtGui import QDragEnterEvent, QDropEvent

from src.ui.theme import PALETTE


class DropArea(QFrame):
    imported = Signal(str)

    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)
        self.setFixedHeight(140)
        self.setStyleSheet(f"""
            QFrame {{
                background-color: {PALETTE["bg_card"]};
                border: 2px dashed {PALETTE["border"]};
                border-radius: 12px;
            }}
            QFrame:hover {{
                border-color: {PALETTE["highlight"]};
                background-color: #222a4a;
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)

        self.icon_label = QLabel("📦")
        self.icon_label.setAlignment(Qt.AlignCenter)
        self.icon_label.setStyleSheet("font-size: 36px; background: transparent; border: none;")

        self.text_label = QLabel("Arraste a pasta do modpack ou um arquivo aqui")
        self.text_label.setAlignment(Qt.AlignCenter)
        self.text_label.setStyleSheet(f"color: {PALETTE['text_secondary']}; font-size: 14px; background: transparent; border: none;")

        self.hint_label = QLabel("ou clique no botão abaixo")
        self.hint_label.setAlignment(Qt.AlignCenter)
        self.hint_label.setStyleSheet(f"color: {PALETTE['text_muted']}; font-size: 11px; background: transparent; border: none;")

        layout.addWidget(self.icon_label)
        layout.addWidget(self.text_label)
        layout.addWidget(self.hint_label)

    def dragEnterEvent(self, event: QDragEnterEvent):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            self.setStyleSheet(f"""
                QFrame {{
                    background-color: #222a4a;
                    border: 2px dashed {PALETTE["highlight"]};
                    border-radius: 12px;
                }}
            """)

    def dragLeaveEvent(self, event):
        self.setStyleSheet(f"""
            QFrame {{
                background-color: {PALETTE["bg_card"]};
                border: 2px dashed {PALETTE["border"]};
                border-radius: 12px;
            }}
        """)

    def dropEvent(self, event: QDropEvent):
        self.setStyleSheet(f"""
            QFrame {{
                background-color: {PALETTE["bg_card"]};
                border: 2px dashed {PALETTE["border"]};
                border-radius: 12px;
            }}
        """)
        urls = [u.toLocalFile() for u in event.mimeData().urls() if u.isLocalFile()]
        if urls:
            self.imported.emit(urls[0])


class ImportWidget(QWidget):
    path_imported = Signal(str)

    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.drop_area = DropArea()
        self.drop_area.imported.connect(self.path_imported.emit)
        layout.addWidget(self.drop_area)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)

        self.btn_folder = QPushButton("📁 Importar Pasta")
        self.btn_folder.clicked.connect(self._import_folder)

        self.btn_file = QPushButton("📄 Importar Arquivo")
        self.btn_file.clicked.connect(self._import_file)

        self.format_combo = QComboBox()
        self.format_combo.addItems(["Auto-detectar", "Pasta de mods", "ZIP (CurseForge)", ".mrpack", "CSV / TXT"])
        self.format_combo.setStyleSheet("max-width: 160px;")

        btn_row.addWidget(self.btn_folder)
        btn_row.addWidget(self.btn_file)
        btn_row.addStretch()
        btn_row.addWidget(self.format_combo)
        layout.addLayout(btn_row)

        self.status_label = QLabel("")
        self.status_label.setStyleSheet(f"color: {PALETTE['text_secondary']}; font-size: 12px; padding: 4px 0;")
        layout.addWidget(self.status_label)

    def _import_folder(self):
        path = QFileDialog.getExistingDirectory(self, "Selecionar pasta de mods")
        if path:
            self.path_imported.emit(path)

    def _import_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Selecionar arquivo",
            filter="Modpacks (*.zip *.mrpack *.csv *.txt);;Todos (*)",
        )
        if path:
            self.path_imported.emit(path)

    def set_status(self, text: str):
        self.status_label.setText(text)
