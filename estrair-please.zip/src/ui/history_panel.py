from PySide6.QtWidgets import QListWidget, QListWidgetItem, QWidget, QVBoxLayout, QLabel
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor

from src.ui.theme import PALETTE, SCORE_COLORS


class HistoryPanel(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        title = QLabel("Histórico")
        title.setStyleSheet(f"color: {PALETTE['text_secondary']}; font-size: 11px; font-weight: 600; "
                            "text-transform: uppercase; letter-spacing: 1px; padding: 8px 0;")
        layout.addWidget(title)

        self.list_widget = QListWidget()
        self.list_widget.setMaximumHeight(250)
        layout.addWidget(self.list_widget)

        self.empty_label = QLabel("Nenhuma análise\nanterior ainda.")
        self.empty_label.setAlignment(Qt.AlignCenter)
        self.empty_label.setStyleSheet(f"color: {PALETTE['text_muted']}; font-size: 12px; padding: 20px;")
        layout.addWidget(self.empty_label)
        self.empty_label.hide()

    def add_entry(self, score: int, label: str, total_mods: int, date: str, analysis_id: int):
        self.empty_label.hide()
        color = SCORE_COLORS.get(label, PALETTE["text_primary"])
        text = f"[{score}/100] {label}  ·  {total_mods} mods  ·  {date}"
        item = QListWidgetItem(text)
        item.setData(Qt.UserRole, analysis_id)
        item.setForeground(QColor(color))
        self.list_widget.addItem(item)

    def clear(self):
        self.list_widget.clear()
        self.empty_label.show()
