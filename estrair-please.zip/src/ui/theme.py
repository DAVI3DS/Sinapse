PALETTE = {
    "bg_primary": "#1a1a2e",
    "bg_secondary": "#16213e",
    "bg_card": "#1e2a4a",
    "accent": "#0f3460",
    "highlight": "#e94560",
    "text_primary": "#eaeaea",
    "text_secondary": "#8892b0",
    "text_muted": "#5a6a8a",
    "success": "#2ecc71",
    "warning": "#f1c40f",
    "danger": "#e74c3c",
    "info": "#3498db",
    "border": "#2a3a5c",
}

SCORE_COLORS = {
    "Estável": "#2ecc71",
    "Moderado": "#f1c40f",
    "Instável": "#e74c3c",
}

STATUS_COLORS = {
    "ok": "#2ecc71",
    "warning": "#f1c40f",
    "conflict": "#e74c3c",
    "missing": "#3498db",
}

ISSUE_ICONS = {
    "missing_dep": "⬇",
    "conflict": "⚡",
    "warning": "⚠",
}
