from PySide6.QtWidgets import (
    QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView,
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QBrush

from src.models.mod import Mod
from src.models.analysis import Issue
from src.ui.theme import PALETTE, STATUS_COLORS, ISSUE_ICONS


class ModListWidget(QTableWidget):
    def __init__(self):
        super().__init__()
        self.setColumnCount(5)
        self.setHorizontalHeaderLabels(["Mod", "Versão", "Status", "Problema", "Ação"])
        self.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeToContents)
        self.setAlternatingRowColors(True)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.verticalHeader().setVisible(False)
        self.setShowGrid(False)

    def set_mods(self, mods: list[Mod], issues: dict[str, Issue]):
        self.setRowCount(len(mods))
        for i, mod in enumerate(mods):
            issue = issues.get(mod.name.lower()) or issues.get(mod.slug.lower())

            name_item = QTableWidgetItem(mod.name)
            name_item.setFlags(name_item.flags() & ~Qt.ItemIsEditable)

            version_item = QTableWidgetItem(mod.version or "—")
            version_item.setFlags(version_item.flags() & ~Qt.ItemIsEditable)

            if issue:
                color_name = "conflict" if issue.issue_type == "conflict" else "missing"
                icon = ISSUE_ICONS.get(issue.issue_type, "⚡")
                status_item = QTableWidgetItem(f"{icon} {issue.issue_type.replace('_', ' ').title()}")
            else:
                status_item = QTableWidgetItem("✓ OK")
                color_name = "ok"

            color = QColor(STATUS_COLORS.get(color_name, PALETTE["text_primary"]))
            status_item.setForeground(QBrush(color))
            status_item.setFlags(status_item.flags() & ~Qt.ItemIsEditable)

            desc_item = QTableWidgetItem(issue.description if issue else "")
            desc_item.setFlags(desc_item.flags() & ~Qt.ItemIsEditable)
            desc_item.setForeground(QBrush(QColor(PALETTE["text_secondary"])))

            action_item = QTableWidgetItem(issue.suggested_action if issue else "")
            action_item.setFlags(action_item.flags() & ~Qt.ItemIsEditable)
            action_item.setForeground(QBrush(QColor(PALETTE["info"])))

            self.setItem(i, 0, name_item)
            self.setItem(i, 1, version_item)
            self.setItem(i, 2, status_item)
            self.setItem(i, 3, desc_item)
            self.setItem(i, 4, action_item)
