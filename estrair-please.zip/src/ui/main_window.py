import json
import csv
import logging
from datetime import datetime
from pathlib import Path

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QSplitter,
    QPushButton, QFileDialog, QMessageBox, QProgressBar, QLabel,
    QFrame,
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QAction

from src.ui.theme import PALETTE
from src.ui.styles import QSS
from src.ui.import_widget import ImportWidget
from src.ui.score_card import ScoreCard
from src.ui.mod_list import ModListWidget
from src.ui.report_widget import ReportWidget
from src.ui.history_panel import HistoryPanel

from src.db.database import Database
from src.models.mod import Mod
from src.models.modpack import Modpack
from src.models.analysis import AnalysisResult, Issue
from src.analysis.scanner import scan
from src.analysis.resolver import Resolver
from src.analysis.scorer import calculate

logger = logging.getLogger(__name__)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Modpack Analyzer")
        self.resize(1200, 780)

        self.db = Database.get()
        self.resolver = Resolver()
        self.current_mods: list[Mod] = []
        self.current_result: AnalysisResult | None = None
        self.current_modpack_id: int | None = None
        self.current_path: str = ""

        self._build_ui()
        self._build_menu()
        self.setStyleSheet(QSS)

    def _build_menu(self):
        menubar = self.menuBar()
        file_menu = menubar.addMenu("Arquivo")

        export_action = QAction("Exportar Relatório", self)
        export_action.triggered.connect(self._export_report)
        file_menu.addAction(export_action)

        export_list_action = QAction("Exportar Lista de Mods", self)
        export_list_action.triggered.connect(self._export_mod_list)
        file_menu.addAction(export_list_action)

        file_menu.addSeparator()
        quit_action = QAction("Sair", self)
        quit_action.triggered.connect(self.close)
        file_menu.addAction(quit_action)

        help_menu = menubar.addMenu("Ajuda")
        about_action = QAction("Sobre", self)
        about_action.triggered.connect(self._show_about)
        help_menu.addAction(about_action)

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(16, 8, 16, 12)
        main_layout.setSpacing(10)

        # Header
        header = QLabel("🔍 Modpack Analyzer")
        header.setStyleSheet(f"font-size: 22px; font-weight: 700; color: {PALETTE['text_primary']}; "
                             f"padding: 4px 0;")
        main_layout.addWidget(header)

        # Splitter: left sidebar | right content
        splitter = QSplitter(Qt.Horizontal)

        # --- Left sidebar ---
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 8, 0)
        left_layout.setSpacing(10)

        self.import_widget = ImportWidget()
        self.import_widget.path_imported.connect(self._on_path_imported)
        left_layout.addWidget(self.import_widget)

        self.history_panel = HistoryPanel()
        self.history_panel.list_widget.itemClicked.connect(self._on_history_click)
        left_layout.addWidget(self.history_panel)
        left_layout.addStretch()

        left_widget.setMinimumWidth(280)
        left_widget.setMaximumWidth(360)
        splitter.addWidget(left_widget)

        # --- Right content ---
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(8, 0, 0, 0)
        right_layout.setSpacing(10)

        self.score_card = ScoreCard()
        right_layout.addWidget(self.score_card)

        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        right_layout.addWidget(self.progress_bar)

        self.mod_list = ModListWidget()
        right_layout.addWidget(self.mod_list, 1)

        tab_label = QLabel("📋 Relatório Detalhado")
        tab_label.setStyleSheet(f"color: {PALETTE['text_secondary']}; font-size: 12px; font-weight: 600; "
                                "padding: 2px 0;")
        right_layout.addWidget(tab_label)

        self.report_widget = ReportWidget()
        right_layout.addWidget(self.report_widget, 1)

        # Action buttons
        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)

        self.btn_analyze = QPushButton("🔍 Analisar Modpack")
        self.btn_analyze.setObjectName("btnPrimary")
        self.btn_analyze.setEnabled(False)
        self.btn_analyze.clicked.connect(self._run_analysis)
        btn_row.addWidget(self.btn_analyze)

        self.btn_export = QPushButton("💾 Exportar Relatório")
        self.btn_export.setEnabled(False)
        self.btn_export.clicked.connect(self._export_report)
        btn_row.addWidget(self.btn_export)

        btn_row.addStretch()

        self.status_info = QLabel("Pronto para começar. Importe um modpack.")
        self.status_info.setStyleSheet(f"color: {PALETTE['text_muted']}; font-size: 12px;")
        btn_row.addWidget(self.status_info)

        right_layout.addLayout(btn_row)

        splitter.addWidget(right_widget)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        main_layout.addWidget(splitter, 1)

    def _on_path_imported(self, path: str):
        self.current_path = path
        self.status_info.setText("Importando...")
        QTimer.singleShot(50, self._do_import)

    def _do_import(self):
        try:
            self.current_mods = scan(self.current_path)
            if not self.current_mods:
                QMessageBox.warning(self, "Importação", "Nenhum mod encontrado no caminho fornecido.")
                self.status_info.setText("Nenhum mod encontrado.")
                return

            name = Path(self.current_path).stem
            self.current_modpack_id = self.db.insert("modpacks",
                name=name,
                game_version="",
                modloader="",
                source_file=self.current_path,
            )
            # Save mods to DB
            for mod in self.current_mods:
                mod_id = self.db.insert("mods",
                    slug=mod.slug,
                    name=mod.name,
                    source=mod.source,
                    source_id=mod.source_id,
                    version=mod.version,
                )
                self.db.insert("modpack_mods", modpack_id=self.current_modpack_id, mod_id=mod_id)

            issue_map: dict[str, Issue] = {}
            self.mod_list.set_mods(self.current_mods, issue_map)
            self.btn_analyze.setEnabled(True)
            self.import_widget.set_status(f"{len(self.current_mods)} mods importados de {Path(self.current_path).name}")
            self.status_info.setText(f"{len(self.current_mods)} mods carregados. Pronto para analisar.")
        except Exception as e:
            logger.exception("Import failed")
            QMessageBox.critical(self, "Erro na Importação", str(e))
            self.status_info.setText(f"Erro: {e}")

    def _run_analysis(self):
        if not self.current_mods:
            return

        self.btn_analyze.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 0)  # indeterminate
        self.status_info.setText("Analisando mods...")

        QTimer.singleShot(100, self._do_analysis)

    def _do_analysis(self):
        try:
            issues = self.resolver.analyze(self.current_mods)
            result = calculate(issues, len(self.current_mods))

            self.current_result = result

            # Build issue map per mod name
            issue_map: dict[str, Issue] = {}
            for iss in result.all_issues:
                key = iss.mod_name.lower()
                if key not in issue_map:
                    issue_map[key] = iss

            self.score_card.set_result(result.score, result.score_label, result.total_mods, len(result.all_issues))
            self.mod_list.set_mods(self.current_mods, issue_map)
            self.report_widget.set_result(result)
            self.btn_export.setEnabled(True)

            # Save to history
            if self.current_modpack_id:
                analysis_id = self.db.insert("analysis_history",
                    modpack_id=self.current_modpack_id,
                    score=result.score,
                    total_mods=result.total_mods,
                    missing_deps=len(result.missing_deps),
                    conflicts=len(result.conflicts),
                )
                for iss in result.all_issues:
                    self.db.insert("analysis_details",
                        analysis_id=analysis_id,
                        mod_name=iss.mod_name,
                        issue_type=iss.issue_type,
                        description=iss.description,
                        suggested_action=iss.suggested_action,
                    )
                now = datetime.now().strftime("%d/%m/%Y %H:%M")
                self.history_panel.add_entry(result.score, result.score_label,
                                              result.total_mods, now, analysis_id)

            self.status_info.setText(f"Análise completa — Score: {result.score}/100 ({result.score_label})")
        except Exception as e:
            logger.exception("Analysis failed")
            QMessageBox.critical(self, "Erro na Análise", str(e))
            self.status_info.setText(f"Erro na análise: {e}")
        finally:
            self.progress_bar.setVisible(False)
            self.btn_analyze.setEnabled(True)

    def _on_history_click(self, item):
        analysis_id = item.data(Qt.UserRole)
        row = self.db.fetch_one("analysis_history", "id=?", (analysis_id,))
        if not row:
            return

        details = self.db.fetch_all("analysis_details", "analysis_id=?", (analysis_id,))
        issues = [
            Issue(d["mod_name"], d["issue_type"], d["description"],
                  "critical" if d["issue_type"] == "missing_dep" else "minor",
                  d["suggested_action"])
            for d in details
        ]

        result = calculate(issues, row["total_mods"])
        result.score = row["score"]
        result.score_label = ["Instável", "Moderado", "Estável"][
            min(2, max(0, (row["score"] - 40) // 20))
        ]
        self.current_result = result
        self.score_card.set_result(result.score, result.score_label, result.total_mods, len(issues))
        self.report_widget.set_result(result)
        self.status_info.setText(f"Histórico: Score {result.score}/100 ({result.score_label})")

    def _export_report(self):
        if not self.current_result:
            return

        path, fmt = QFileDialog.getSaveFileName(
            self, "Exportar Relatório", "relatorio_modpack",
            "JSON (*.json);;CSV (*.csv)",
        )
        if not path:
            return

        try:
            if path.endswith(".csv"):
                self._export_csv(path)
            else:
                self._export_json(path)
            self.status_info.setText(f"Relatório exportado: {Path(path).name}")
        except Exception as e:
            QMessageBox.critical(self, "Erro ao Exportar", str(e))

    def _export_json(self, path: str):
        r = self.current_result
        data = {
            "score": r.score,
            "label": r.score_label,
            "total_mods": r.total_mods,
            "issues": [
                {"mod": i.mod_name, "type": i.issue_type, "desc": i.description,
                 "severity": i.severity, "action": i.suggested_action}
                for i in r.all_issues
            ],
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    def _export_csv(self, path: str):
        r = self.current_result
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["Mod", "Tipo", "Descrição", "Severidade", "Ação Sugerida"])
            for i in r.all_issues:
                writer.writerow([i.mod_name, i.issue_type, i.description, i.severity, i.suggested_action])

    def _export_mod_list(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Exportar Lista de Mods", "mods.txt",
            "Texto (*.txt);;CSV (*.csv)",
        )
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                for mod in self.current_mods:
                    f.write(f"{mod.name},{mod.slug},{mod.version}\n")
            self.status_info.setText(f"Lista exportada: {Path(path).name}")
        except Exception as e:
            QMessageBox.critical(self, "Erro ao Exportar", str(e))

    def _show_about(self):
        QMessageBox.about(self, "Sobre o Modpack Analyzer",
            "Modpack Analyzer v1.0\n\n"
            "Ferramenta desktop para análise de modpacks de jogos.\n"
            "Detecta incompatibilidades e dependências ausentes.\n\n"
            "Feito com Python, PySide6 e 💙")
