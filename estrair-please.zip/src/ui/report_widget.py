from PySide6.QtWidgets import QTextBrowser
from PySide6.QtCore import Qt

from src.models.analysis import AnalysisResult
from src.ui.theme import PALETTE, SCORE_COLORS


class ReportWidget(QTextBrowser):
    def __init__(self):
        super().__init__()
        self.setOpenExternalLinks(True)
        self.setPlaceholderText("Relatório de análise aparecerá aqui após a análise.")

    def set_result(self, result: AnalysisResult):
        color = SCORE_COLORS.get(result.score_label, PALETTE["text_primary"])
        html = f"""
        <h2 style="color: {PALETTE['text_primary']}; margin-bottom: 4px;">
            Score: <span style="color:{color};">{result.score}/100 — {result.score_label}</span>
        </h2>
        <p style="color: {PALETTE['text_muted']}; margin-top: 0;">
            {result.total_mods} mods analisados · {len(result.all_issues)} problemas encontrados
        </p>
        <hr style="border-color: {PALETTE['border']};">
        """

        if result.missing_deps:
            html += f'<h3 style="color: {PALETTE["info"]};">⬇ Dependências Ausentes ({len(result.missing_deps)})</h3>'
            for d in result.missing_deps:
                html += f"""
                <div style="background: {PALETTE['bg_card']}; padding: 8px 12px; border-radius: 6px; margin-bottom: 6px;">
                    <b>{d.mod_name}</b> — {d.description}
                    <br><span style="color: {PALETTE['text_muted']};">→ {d.suggested_action}</span>
                </div>
                """

        if result.conflicts:
            html += f'<h3 style="color: {PALETTE["danger"]};">⚡ Conflitos ({len(result.conflicts)})</h3>'
            for c in result.conflicts:
                html += f"""
                <div style="background: {PALETTE['bg_card']}; padding: 8px 12px; border-radius: 6px; margin-bottom: 6px;">
                    <b>{c.mod_name}</b> — {c.description}
                    <br><span style="color: {PALETTE['text_muted']};">→ {c.suggested_action}</span>
                </div>
                """

        if result.warnings:
            html += f'<h3 style="color: {PALETTE["warning"]};">⚠ Avisos ({len(result.warnings)})</h3>'
            for w in result.warnings:
                html += f"""
                <div style="background: {PALETTE['bg_card']}; padding: 8px 12px; border-radius: 6px; margin-bottom: 6px;">
                    <b>{w.mod_name}</b> — {w.description}
                </div>
                """

        if not result.all_issues:
            html += f"""
            <div style="text-align: center; padding: 24px;">
                <span style="font-size: 48px;">✅</span>
                <p style="color: {PALETTE['success']}; font-size: 16px;">Nenhum problema encontrado! Modpack estável.</p>
            </div>
            """

        self.setHtml(html)
