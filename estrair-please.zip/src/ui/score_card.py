from PySide6.QtWidgets import QFrame, QVBoxLayout, QLabel, QHBoxLayout, QWidget
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QPainter, QColor, QPen, QBrush, QFont

from src.ui.theme import PALETTE, SCORE_COLORS


class StabilityGauge(QWidget):
    """Círculo de progresso do score."""
    def __init__(self, score: int = 0):
        super().__init__()
        self._score = score
        self.setFixedSize(130, 130)

    def set_score(self, score: int):
        self._score = score
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        rect = self.rect().adjusted(8, 8, -8, -8)
        start_angle = 90 * 16
        span = int(360 * (self._score / 100.0)) * 16

        if self._score >= 80:
            color = QColor(PALETTE["success"])
        elif self._score >= 50:
            color = QColor(PALETTE["warning"])
        else:
            color = QColor(PALETTE["danger"])

        # background circle
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(QColor(PALETTE["bg_card"])))
        painter.drawEllipse(rect)

        # progress arc
        pen = QPen(color, 8, Qt.SolidLine, Qt.RoundCap)
        painter.setPen(pen)
        painter.setBrush(Qt.NoBrush)
        painter.drawArc(rect, start_angle, span)

        # center text
        painter.setPen(Qt.NoPen)
        font = QFont("Segoe UI", 28, QFont.Bold)
        painter.setFont(font)
        painter.setPen(QColor(PALETTE["text_primary"]))
        painter.drawText(rect, Qt.AlignCenter, str(self._score))


class ScoreCard(QFrame):
    def __init__(self):
        super().__init__()
        self.setStyleSheet(f"""
            ScoreCard {{
                background-color: {PALETTE["bg_card"]};
                border: 1px solid {PALETTE["border"]};
                border-radius: 12px;
            }}
        """)
        self.setFixedHeight(180)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(24, 16, 24, 16)

        # Gauge
        self.gauge = StabilityGauge(0)
        layout.addWidget(self.gauge)

        # Labels
        label_layout = QVBoxLayout()
        label_layout.setSpacing(4)

        self.label_title = QLabel("Estabilidade")
        self.label_title.setStyleSheet(f"color: {PALETTE['text_secondary']}; font-size: 12px; background: transparent; border: none;")

        self.label_score_text = QLabel("--")
        self.label_score_text.setStyleSheet(f"color: {PALETTE['text_primary']}; font-size: 32px; font-weight: bold; background: transparent; border: none;")

        self.label_detail = QLabel(f"0 mods analisados")
        self.label_detail.setStyleSheet(f"color: {PALETTE['text_muted']}; font-size: 13px; background: transparent; border: none;")

        label_layout.addWidget(self.label_title)
        label_layout.addWidget(self.label_score_text)
        label_layout.addWidget(self.label_detail)
        label_layout.addStretch()

        layout.addLayout(label_layout, 1)

    def set_result(self, score: int, label: str, total_mods: int, issues_count: int):
        self.gauge.set_score(score)
        color = SCORE_COLORS.get(label, PALETTE["text_primary"])
        self.label_score_text.setText(f"{label}")
        self.label_score_text.setStyleSheet(f"color: {color}; font-size: 28px; font-weight: bold; background: transparent; border: none;")
        self.label_detail.setText(f"{total_mods} mods · {issues_count} problemas")
