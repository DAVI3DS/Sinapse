QSS = """
QMainWindow, QWidget {
    background-color: #1a1a2e;
    color: #eaeaea;
    font-family: 'Segoe UI', 'SF Pro Display', 'Helvetica Neue', sans-serif;
}

QPushButton {
    background-color: #0f3460;
    color: #eaeaea;
    border: 1px solid #2a3a5c;
    border-radius: 6px;
    padding: 8px 18px;
    font-size: 13px;
    font-weight: 500;
}
QPushButton:hover {
    background-color: #1a4a80;
    border-color: #3498db;
}
QPushButton:pressed {
    background-color: #0a2550;
}
QPushButton:disabled {
    background-color: #2a2a3e;
    color: #5a6a8a;
}

QPushButton#btnPrimary {
    background-color: #e94560;
    border: none;
    color: #fff;
    font-weight: 600;
}
QPushButton#btnPrimary:hover {
    background-color: #d63850;
}

QLabel {
    color: #eaeaea;
    font-size: 13px;
}

QTableWidget {
    background-color: #16213e;
    alternate-background-color: #1a2a4a;
    border: 1px solid #2a3a5c;
    border-radius: 8px;
    gridline-color: #2a3a5c;
    selection-background-color: #0f3460;
    selection-color: #fff;
    font-size: 13px;
}
QTableWidget::item {
    padding: 6px 10px;
}
QHeaderView::section {
    background-color: #0f3460;
    color: #eaeaea;
    padding: 8px 10px;
    border: none;
    border-right: 1px solid #2a3a5c;
    font-weight: 600;
    font-size: 12px;
    text-transform: uppercase;
}

QListWidget {
    background-color: #16213e;
    border: 1px solid #2a3a5c;
    border-radius: 8px;
    font-size: 13px;
}
QListWidget::item {
    padding: 8px 12px;
    border-bottom: 1px solid #2a3a5c;
}
QListWidget::item:hover {
    background-color: #1e2a4a;
}
QListWidget::item:selected {
    background-color: #0f3460;
}

QTextBrowser {
    background-color: #16213e;
    border: 1px solid #2a3a5c;
    border-radius: 8px;
    padding: 12px;
    font-size: 13px;
}

QGroupBox {
    font-weight: 600;
    font-size: 14px;
    border: 1px solid #2a3a5c;
    border-radius: 8px;
    margin-top: 12px;
    padding-top: 20px;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    padding: 4px 12px;
    color: #8892b0;
}

QScrollBar:vertical {
    background: #1a1a2e;
    width: 10px;
    border-radius: 5px;
}
QScrollBar::handle:vertical {
    background: #2a3a5c;
    border-radius: 5px;
    min-height: 30px;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0;
}

QProgressBar {
    background-color: #16213e;
    border: 1px solid #2a3a5c;
    border-radius: 6px;
    text-align: center;
    font-size: 12px;
    height: 20px;
}
QProgressBar::chunk {
    background-color: #e94560;
    border-radius: 5px;
}
"""
