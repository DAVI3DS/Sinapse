import logging
import re
from typing import Optional

from src.models.mod import Mod
from src.models.analysis import Issue
from src.api.modrinth import ModrinthClient
from src.api.curseforge import CurseForgeClient
from src.db.database import Database

logger = logging.getLogger(__name__)

_VERSION_PATTERNS = re.compile(
    r"[-_+](?:mc)?\d+\.\d+(?:\.\d+)?(?:pre\d*|beta\d*|alpha\d*)?"
    r"|[-_+](?:forge|fabric|neoforge|quilt)"
    r"|[-_+]\d+\.\d+\.\d+(?:[.+][\w.-]+)?"
    r"|[-_+]v?\d+(?:\.\d+)+(?:[.+][\w.-]+)?"
    r"|[-_+]\d{4,}"
    r"|[-_+](?:all|client|server|universal)"
    r"|\.jar$",
    re.IGNORECASE,
)


def _strip_version(name: str) -> str:
    name = _VERSION_PATTERNS.sub("", name)
    name = re.sub(r"[-_+]+", "-", name).strip("-")
    name = re.sub(r"\.(?=\d)", "", name)
    name = re.sub(r"--+", "-", name).strip("-")
    name = re.sub(r"^\d+(\.\d+)*[-_]", "", name)
    return name or name


def _slugify(name: str) -> str:
    return re.sub(r"[^a-z0-9_-]", "", name.lower().replace(" ", "-"))[:80]


class Resolver:
    def __init__(self):
        self.modrinth = ModrinthClient()
        self.curseforge = CurseForgeClient()
        self.db = Database.get()

    def analyze(self, mods: list[Mod], **kwargs) -> list[Issue]:
        issues: list[Issue] = []

        # Build name-based matcher: for each mod in pack, store all known names
        pack_names: set[str] = set()
        for m in mods:
            pack_names.add(m.name.lower())
            pack_names.add(_slugify(m.name))
            pack_names.add(_strip_version(m.name).lower())
            if m.slug:
                pack_names.add(m.slug.lower())

        for mod in mods:
            resolved = self._resolve_mod(mod)
            if not resolved:
                issues.append(Issue(
                    mod_name=mod.name,
                    issue_type="warning",
                    severity="minor",
                    description="Mod não identificado nas APIs",
                ))
                continue

            deps = self._fetch_all_deps(resolved)
            if deps:
                for dep in deps:
                    dep_slug = (dep.get("depends_on_slug") or "").lower()
                    dep_name = dep.get("name", dep_slug).lower()
                    dep_type = dep.get("type", "required")

                    # Check if this dep is already in the pack (by slug or name)
                    in_pack = dep_slug in pack_names or dep_name in pack_names
                    # Also fuzzy-check: does any pack name contain the dep name or vice versa?
                    if not in_pack:
                        for pn in pack_names:
                            if dep_name in pn or pn in dep_name:
                                in_pack = True
                                break

                    if dep_slug and not in_pack:
                        sev = "critical" if dep_type == "required" else "minor"
                        action = f"Instalar {dep_name}" if dep_type == "required" else f"Considerar {dep_name}"
                        issues.append(Issue(
                            mod_name=mod.name,
                            issue_type="missing_dep",
                            severity=sev,
                            description=f"{'Requer' if dep_type == 'required' else 'Recomendado'}: {dep_name}",
                            suggested_action=action,
                        ))

            incompats = self._fetch_all_incompats(resolved)
            if incompats:
                for inc in incompats:
                    inc_slug = (inc.get("mod_b_slug") or "").lower()
                    inc_name = inc.get("name", inc_slug)
                    if inc_slug and inc_slug in all_ids:
                        issues.append(Issue(
                            mod_name=mod.name,
                            issue_type="conflict",
                            severity=inc.get("severity", "critical"),
                            description=f"Incompatível com {inc_name}: {inc.get('description', 'Conflito conhecido')}",
                            suggested_action=f"Remover {mod.name} ou {inc_name}",
                        ))

        return issues

    def _resolve_mod(self, mod: Mod) -> Optional[Mod]:
        # If slug is clean enough, try direct lookup
        slug = mod.slug or _slugify(_strip_version(mod.name))
        try:
            info = self.modrinth.get_mod(slug)
            if info and isinstance(info, dict) and info.get("id"):
                return Mod(
                    name=info.get("title", mod.name),
                    slug=slug,
                    source="modrinth",
                    source_id=slug,
                )
        except Exception:
            pass

        # Try DB cache (only if the cached mod has a known source)
        candidate = self._search_in_db(mod)
        if candidate and candidate.source in ("modrinth", "curseforge") and candidate.source_id:
            return candidate

        # Search Modrinth with cleaned name
        clean = _strip_version(mod.name)
        try:
            hits = self.modrinth.search_mod(clean, limit=5)
            if hits:
                best = self._best_match(hits, clean, mod.name)
                if best:
                    slug = best.get("slug") or best.get("project_id", "")
                    title = best.get("title", slug)
                    logger.info("Resolved '%s' -> '%s' (%s)", mod.name, slug, title)
                    return Mod(name=title, slug=slug, source="modrinth", source_id=slug)
        except Exception as e:
            logger.warning("Search failed for '%s': %s", mod.name, e)

        return None

    def _best_match(self, hits: list[dict], clean_name: str, original: str) -> Optional[dict]:
        clean_lower = clean_name.lower()
        scored = []
        for h in hits:
            s = 0
            slug = (h.get("slug") or "").lower()
            title = (h.get("title") or "").lower()
            if slug == clean_lower or _slugify(original) in (slug, title):
                s += 100
            if clean_lower in slug or slug in clean_lower:
                s += 40
            if clean_lower in title or title in clean_lower:
                s += 30
            words = set(clean_lower.replace("-", " ").split())
            tw = set(title.replace("-", " ").split())
            s += len(words & tw) * 10
            if h.get("project_type") == "mod":
                s += 15
            scored.append((s, h))
        scored.sort(key=lambda x: x[0], reverse=True)
        return scored[0][1] if scored and scored[0][0] > 0 else None

    def _search_in_db(self, mod: Mod) -> Optional[Mod]:
        clean = _strip_version(mod.name)
        for c in {mod.slug, _slugify(mod.name), _slugify(clean), mod.name.lower(), clean.lower()}:
            if not c:
                continue
            row = self.db.fetch_one("mods", "slug=? COLLATE NOCASE OR name=? COLLATE NOCASE", (c, c))
            if row:
                return Mod(id=row["id"], slug=row["slug"], name=row["name"],
                           source=row["source"], source_id=row["source_id"])
        return None

    def _fetch_all_deps(self, mod: Mod) -> list[dict]:
        """Fetch deps from both project-level and version-level APIs."""
        if mod.source != "modrinth":
            return []
        all_deps = {}

        # Project-level
        try:
            raw = self.modrinth.get_dependencies(mod.slug)
            for entry in raw:
                dep_type = entry.get("dependency_type", "")
                if dep_type == "incompatible":
                    continue
                pid = entry.get("project_id", "")
                if pid and dep_type == "required":
                    all_deps[pid] = {"depends_on_slug": pid, "type": dep_type}
        except Exception:
            pass

        # Version-level (more reliable)
        try:
            versions = self.modrinth.get_versions(mod.slug)
            for ver in versions[:5]:  # check latest 5 versions
                for dep in ver.get("dependencies", []):
                    dep_type = dep.get("dependency_type", "")
                    if dep_type == "incompatible":
                        continue
                    pid = dep.get("project_id", "")
                    if pid and pid not in all_deps:
                        all_deps[pid] = {"depends_on_slug": pid, "type": dep_type}
        except Exception:
            pass

        # Resolve names
        result = []
        for pid, entry in all_deps.items():
            try:
                info = self.modrinth.get_mod(pid)
                name = info.get("title", pid) if isinstance(info, dict) else pid
            except Exception:
                name = pid
            entry["name"] = name
            result.append(entry)
        return result

    def _fetch_all_incompats(self, mod: Mod) -> list[dict]:
        """Fetch incompatibilities from both project and version level."""
        if mod.source != "modrinth":
            return []
        seen = set()
        result = []

        # Project-level
        try:
            raw = self.modrinth.get_dependencies(mod.slug)
            for entry in raw:
                if entry.get("dependency_type") == "incompatible":
                    pid = entry.get("project_id", "")
                    if pid and pid not in seen:
                        seen.add(pid)
                        try:
                            info = self.modrinth.get_mod(pid)
                            name = info.get("title", pid) if isinstance(info, dict) else pid
                        except Exception:
                            name = pid
                        result.append({
                            "mod_b_slug": pid, "name": name,
                            "description": entry.get("description", "Incompatibilidade conhecida"),
                            "severity": "critical",
                        })
        except Exception:
            pass

        # Version-level
        try:
            versions = self.modrinth.get_versions(mod.slug)
            for ver in versions[:5]:
                for dep in ver.get("dependencies", []):
                    if dep.get("dependency_type") == "incompatible":
                        pid = dep.get("project_id", "")
                        if pid and pid not in seen:
                            seen.add(pid)
                            try:
                                info = self.modrinth.get_mod(pid)
                                name = info.get("title", pid) if isinstance(info, dict) else pid
                            except Exception:
                                name = pid
                            result.append({
                                "mod_b_slug": pid, "name": name,
                                "description": dep.get("description", "Incompatibilidade conhecida"),
                                "severity": "critical",
                            })
        except Exception:
            pass

        return result
