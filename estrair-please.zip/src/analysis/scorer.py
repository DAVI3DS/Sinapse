from src.models.analysis import AnalysisResult, Issue


def calculate(issues: list[Issue], total_mods: int) -> AnalysisResult:
    """Calcula score de estabilidade 0-100 baseado nos issues encontrados."""
    score = 100

    missing_deps: list[Issue] = []
    conflicts: list[Issue] = []
    warnings: list[Issue] = []

    for issue in issues:
        if issue.issue_type == "missing_dep":
            if issue.severity == "critical":
                score -= 15
            else:
                score -= 2
            missing_deps.append(issue)
        elif issue.issue_type == "conflict":
            if issue.severity == "critical":
                score -= 10
            elif issue.severity == "major":
                score -= 5
            else:
                score -= 3
            conflicts.append(issue)
        else:
            score -= 2
            warnings.append(issue)

    score = max(0, min(100, score))

    if score >= 80:
        label = "Estavel"
    elif score >= 50:
        label = "Moderado"
    else:
        label = "Instavel"

    return AnalysisResult(
        score=score,
        score_label=label,
        total_mods=total_mods,
        missing_deps=missing_deps,
        conflicts=conflicts,
        warnings=warnings,
        issues=issues,
    )
