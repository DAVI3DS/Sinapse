import os
import csv
import json
import zipfile
import re
import logging
from pathlib import Path
from typing import Optional

from src.models.mod import Mod

logger = logging.getLogger(__name__)


def scan(path: str) -> list[Mod]:
    """Detecta formato e extrai lista de mods do caminho fornecido."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Caminho não encontrado: {path}")

    if p.is_dir():
        return _scan_folder(p)
    elif p.suffix == ".zip":
        return _scan_zip(p)
    elif p.suffix == ".mrpack":
        return _scan_mrpack(p)
    elif p.suffix in (".csv", ".txt"):
        return _scan_text_list(p)
    elif p.suffix == ".json":
        if p.name == "manifest.json":
            return _parse_curseforge_manifest(p, p.parent)
        elif p.name == "modrinth.index.json":
            return _parse_modrinth_index(p, p.parent)
        else:
            mods = _scan_text_list(p)
            if not mods:
                raise ValueError(f"Formato JSON não reconhecido: {p.name}")
            return mods
    else:
        raise ValueError(f"Formato não suportado: {p.suffix}")


def _scan_folder(path: Path) -> list[Mod]:
    """Lê pasta de mods — arquivos .jar / pasta mods em instância."""
    mods = []
    # Se tem manifest.json, é instância CurseForge
    manifest = path / "manifest.json"
    if manifest.exists():
        return _parse_curseforge_manifest(manifest, path)

    # Se tem modrinth.index.json, é .mrpack extraído
    index = path / "modrinth.index.json"
    if index.exists():
        return _parse_modrinth_index(index, path)

    # Fallback: listar .jar / .toml
    for f in sorted(path.iterdir()):
        if f.suffix == ".jar":
            name = _name_from_jar(f) or f.stem
            mods.append(Mod(name=name, slug=_slugify(name)))
        elif f.suffix == ".toml" and f.name == "mods.toml":
            mods.extend(_parse_mods_toml(f))
    return mods


def _scan_zip(path: Path) -> list[Mod]:
    """Extrai e lê .zip (perfil CurseForge)."""
    with zipfile.ZipFile(path) as zf:
        if "manifest.json" in zf.namelist():
            data = json.loads(zf.read("manifest.json"))
            return _parse_curseforge_manifest_data(data)
        if "modrinth.index.json" in zf.namelist():
            data = json.loads(zf.read("modrinth.index.json"))
            return _parse_modrinth_index_data(data)
    raise ValueError("ZIP não contém manifest.json ou modrinth.index.json")


def _scan_mrpack(path: Path) -> list[Mod]:
    """Lê .mrpack (Modrinth pack — é um ZIP)."""
    with zipfile.ZipFile(path) as zf:
        data = json.loads(zf.read("modrinth.index.json"))
        return _parse_modrinth_index_data(data)


def _scan_text_list(path: Path) -> list[Mod]:
    """Lê CSV ou TXT com nomes de mods."""
    mods = []
    with open(path, newline="", encoding="utf-8", errors="replace") as f:
        if path.suffix == ".csv":
            reader = csv.reader(f)
            for row in reader:
                if row and row[0].strip():
                    mods.append(Mod(name=row[0].strip(), slug=_slugify(row[0].strip())))
        else:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    # Formato: nome,mod_slug,url opcional
                    parts = [p.strip() for p in line.split(",")]
                    mods.append(Mod(name=parts[0], slug=_slugify(parts[0])))
    return mods


def _parse_curseforge_manifest(manifest_path: Path, mods_dir: Path) -> list[Mod]:
    with open(manifest_path, encoding="utf-8") as f:
        data = json.load(f)
    return _parse_curseforge_manifest_data(data)


def _parse_curseforge_manifest_data(data: dict) -> list[Mod]:
    mods = []
    for entry in data.get("files", []):
        project_id = str(entry.get("projectID", ""))
        file_id = str(entry.get("fileID", ""))
        name = entry.get("name", f"curseforge-{project_id}")
        mods.append(Mod(
            name=name,
            source="curseforge",
            source_id=project_id,
            version=file_id,
        ))
    return mods


def _parse_modrinth_index(index_path: Path, base_dir: Path) -> list[Mod]:
    with open(index_path, encoding="utf-8") as f:
        data = json.load(f)
    return _parse_modrinth_index_data(data)


def _parse_modrinth_index_data(data: dict) -> list[Mod]:
    mods = []
    for entry in data.get("files", []):
        downloads = entry.get("downloads", [])
        url = downloads[0] if downloads else ""
        fname = entry.get("path", "")
        hashes = entry.get("hashes", {})
        mods.append(Mod(
            name=Path(fname).stem,
            slug=_slugify(Path(fname).stem),
            source="modrinth",
            source_id=hashes.get("sha1", ""),
            download_url=url,
        ))
    # Also add dependencies from index
    for dep in data.get("dependencies", {}).get("modrinth", {}).values():
        if dep not in [m.slug for m in mods]:
            mods.append(Mod(
                name=dep,
                slug=dep,
                source="modrinth",
            ))
    return mods


def _name_from_jar(jar_path: Path) -> Optional[str]:
    """Tenta extrair nome do mod de dentro do .jar (fabric.mod.json ou mods.toml)."""
    try:
        with zipfile.ZipFile(jar_path) as zf:
            if "fabric.mod.json" in zf.namelist():
                data = json.loads(zf.read("fabric.mod.json"))
                return data.get("name") or data.get("id")
            if "META-INF/neoforge.mods.toml" in zf.namelist():
                import tomllib
                data = tomllib.loads(zf.read("META-INF/neoforge.mods.toml").decode())
                mods_list = data.get("mods", [])
                if mods_list:
                    return mods_list[0].get("displayName") or mods_list[0].get("modId")
            if "META-INF/mods.toml" in zf.namelist():
                import tomllib
                data = tomllib.loads(zf.read("META-INF/mods.toml").decode())
                mods_list = data.get("mods", [])
                if mods_list:
                    return mods_list[0].get("displayName") or mods_list[0].get("modId")
    except Exception:
        pass
    return None


def _parse_mods_toml(toml_path: Path) -> list[Mod]:
    try:
        import tomllib
        with open(toml_path, "rb") as f:
            data = tomllib.load(f)
        mods = []
        for entry in data.get("mods", []):
            mods.append(Mod(
                name=entry.get("displayName", entry.get("modId", "")),
                slug=entry.get("modId", ""),
            ))
        return mods
    except Exception:
        return []


_slug_re = re.compile(r"[^a-z0-9_-]")


def _slugify(name: str) -> str:
    return _slug_re.sub("", name.lower().replace(" ", "-"))[:80]
