import os
import logging
from typing import Optional

from src.api.base import BaseAPIClient, APIError

logger = logging.getLogger(__name__)

CURSEFORGE_API = "https://api.curseforge.com/v1"


class CurseForgeClient(BaseAPIClient):
    BASE_URL = CURSEFORGE_API

    def __init__(self):
        super().__init__()
        self.api_key = os.environ.get("CURSEFORGE_API_KEY", "")
        if self.api_key:
            self.session.headers["x-api-key"] = self.api_key

    @property
    def is_available(self) -> bool:
        return bool(self.api_key)

    def search_mod(self, query: str, limit: int = 10) -> list[dict]:
        data = self._get(
            f"{CURSEFORGE_API}/mods/search",
            params={"searchFilter": query, "pageSize": limit},
        )
        return data.get("data", [])

    def get_mod(self, mod_id: str) -> dict:
        data = self._get(f"{CURSEFORGE_API}/mods/{mod_id}")
        return data.get("data", {})

    def get_dependencies(self, mod_id: str) -> list[dict]:
        data = self._get(f"{CURSEFORGE_API}/mods/{mod_id}/dependencies")
        return data.get("data", [])

    def get_files(self, mod_id: str) -> list[dict]:
        data = self._get(f"{CURSEFORGE_API}/mods/{mod_id}/files")
        return data.get("data", [])
