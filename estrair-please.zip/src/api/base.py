import time
import logging
from datetime import datetime, timedelta
from typing import Optional, Any
from urllib.parse import urlencode

import requests

from src.db.database import Database

logger = logging.getLogger(__name__)


class APIError(Exception):
    pass


class APIRateLimit(APIError):
    pass


class BaseAPIClient:
    BASE_URL = ""
    CACHE_TTL_HOURS = 24

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update(self._default_headers())
        self.db = Database.get()
        self._last_request = 0.0
        self.min_interval = 0.5  # 500ms entre chamadas

    def _default_headers(self) -> dict:
        return {
            "User-Agent": "ModpackAnalyzer/1.0",
            "Accept": "application/json",
        }

    def _rate_limit(self):
        elapsed = time.time() - self._last_request
        if elapsed < self.min_interval:
            time.sleep(self.min_interval - elapsed)
        self._last_request = time.time()

    def _get(self, url: str, params: dict = None, cache_key: str = "", use_cache: bool = True) -> dict:
        self._rate_limit()
        try:
            resp = self.session.get(url, params=params, timeout=15)
            resp.raise_for_status()
            return resp.json()
        except requests.exceptions.HTTPError as e:
            if resp.status_code == 429:
                raise APIRateLimit(f"Rate limit: {e}") from e
            raise APIError(f"HTTP {resp.status_code}: {e}") from e
        except requests.exceptions.ConnectionError as e:
            raise APIError(f"Connection failed: {e}") from e
        except requests.exceptions.Timeout as e:
            raise APIError(f"Timeout: {e}") from e

    def search_mod(self, query: str) -> list[dict]:
        raise NotImplementedError

    def get_mod(self, mod_id: str) -> dict:
        raise NotImplementedError

    def get_dependencies(self, mod_id: str) -> list[dict]:
        raise NotImplementedError
