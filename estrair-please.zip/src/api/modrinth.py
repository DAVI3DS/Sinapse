import logging
from typing import Optional

from src.api.base import BaseAPIClient

logger = logging.getLogger(__name__)

MODRINTH_API = "https://api.modrinth.com/v2"


class ModrinthClient(BaseAPIClient):
    BASE_URL = MODRINTH_API

    def search_mod(self, query: str, limit: int = 10) -> list[dict]:
        data = self._get(f"{MODRINTH_API}/search", params={"query": query, "limit": limit})
        return data.get("hits", [])

    def get_mod(self, slug_or_id: str) -> dict:
        return self._get(f"{MODRINTH_API}/project/{slug_or_id}")

    def get_dependencies(self, project_id: str) -> list[dict]:
        data = self._get(f"{MODRINTH_API}/project/{project_id}/dependencies")
        return data.get("dependencies", [])

    def get_versions(self, project_id: str) -> list[dict]:
        return self._get(f"{MODRINTH_API}/project/{project_id}/version")

    def resolve_slug(self, query: str) -> Optional[str]:
        hits = self.search_mod(query, limit=1)
        if hits:
            return hits[0].get("slug") or hits[0].get("project_id")
        return None
