from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Mod:
    id: Optional[int] = None
    slug: str = ""
    name: str = ""
    source: str = ""  # curseforge | modrinth
    source_id: str = ""
    description: str = ""
    game_versions: str = ""  # comma-separated, e.g. "1.20,1.20.1"
    modloader: str = ""  # forge | fabric | quilt | neoforge
    download_url: str = ""
    version: str = ""
    cached_at: Optional[str] = None

    @property
    def is_identified(self) -> bool:
        return bool(self.slug or self.source_id)
