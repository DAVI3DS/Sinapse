from dataclasses import dataclass, field
from typing import Optional
from src.models.mod import Mod


@dataclass
class Modpack:
    id: Optional[int] = None
    name: str = ""
    game_version: str = ""
    modloader: str = ""
    source_file: str = ""
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    mods: list[Mod] = field(default_factory=list)
