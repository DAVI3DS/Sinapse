from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Issue:
    mod_name: str
    issue_type: str  # missing_dep | conflict | warning
    description: str
    severity: str  # critical | major | minor
    suggested_action: str = ""


@dataclass
class AnalysisResult:
    score: int = 0
    score_label: str = ""
    total_mods: int = 0
    missing_deps: list[Issue] = field(default_factory=list)
    conflicts: list[Issue] = field(default_factory=list)
    warnings: list[Issue] = field(default_factory=list)
    issues: list[Issue] = field(default_factory=list)
    created_at: Optional[str] = None

    @property
    def all_issues(self) -> list[Issue]:
        return self.missing_deps + self.conflicts + self.warnings
